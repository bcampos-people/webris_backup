import { Component, ViewChild, OnInit } from '@angular/core';

declare var $;

@Component({
  selector: 'app-ditafone',
  templateUrl: './ditafone.component.html',
  styleUrls: ['./ditafone.component.scss']
})
export class DitafoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
