export class TableColResize {
}
